//
//  MediaViewController.swift
//  LazyHue
//
//  Created by 양창엽 on 2017. 8. 18..
//  Copyright © 2017년 Yang-Chang-Yeop. All rights reserved.
//

import UIKit

class MediaViewController: UIViewController
{

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
