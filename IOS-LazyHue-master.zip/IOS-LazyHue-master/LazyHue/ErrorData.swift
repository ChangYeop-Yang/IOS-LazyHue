//
//  ErrorData.swift
//  LazyHue
//
//  Created by 양창엽 on 2017. 8. 14..
//  Copyright © 2017년 Yang-Chang-Yeop. All rights reserved.
//

import Foundation

class ErrorData
{
    enum BRIDGE_ERROR:String
    {
        case BRIDGE_CACHE_EMPTY = "Error, Empty Bridge Light List."
    }
}
