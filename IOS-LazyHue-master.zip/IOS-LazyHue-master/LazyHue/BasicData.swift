//
//  BasicDate.swift
//  LazyHue
//
//  Created by 양창엽 on 2017. 8. 7..
//  Copyright © 2017년 Yang-Chang-Yeop. All rights reserved.
//

import Foundation

class BasicData
{
    /* MARK - Static RGB Variable */
    public static let F_RGB_MAX_VALUE:Float = 255.0
    
    /* MARK - Static BOOL Variable */
    public static let TRUE_VALUE:Int32 = 1
    public static let FALUSE_VALUE:Int32 = 0
}
